import tensorflow as tf
import utilities
import math
from weighted_average import weighted_average

# model.py: All functions related to the model are here including weight initialization, network evaluation, error,
# and optimization


def InitializeWeights(layers, kernels, scope, FLAGS):

    with tf.variable_scope(scope):
        
        # Loop through all of the layers and initialize the weights (Xavier initialization)
        weights = []
        biases = []
        n = len(layers)
        assert(n == len(kernels))   
        for i in xrange(0, n-1):
            weights.append(tf.get_variable("conv" + str(i + 1), shape=[kernels[i], kernels[i], layers[i], layers[i+1]],
                            initializer=tf.contrib.layers.xavier_initializer_conv2d(dtype=tf.float32, seed=FLAGS.seed)))
            biases.append(tf.Variable(tf.zeros([layers[i+1]], dtype=tf.float32)))

        assert(kernels[n-1] is None)

        return weights, biases


def EvaluateNetwork(data, params, batchSize, isTraining, FLAGS):

  # Initialize the network weights
  weightsDiffuse, biasesDiffuse = InitializeWeights(params['layersDiffuse'], params['kernels'], 'diff', FLAGS)
  weightsSpecular, biasesSpecular = InitializeWeights(params['layersSpecular'], params['kernels'], 'spec', FLAGS)

  # Evaluate the network
  networkInDiffuse = data['diffInput']
  networkInSpecular = data['specInput']
  networkOutDiffuse = FeedForward(networkInDiffuse, weightsDiffuse, biasesDiffuse, isTraining)
  networkOutSpecular = FeedForward(networkInSpecular, weightsSpecular, biasesSpecular, isTraining)

  if FLAGS.isKernelPrediction:

    # Crop and re-arrange data for kernel
    inputDims = data['diffInput'].get_shape().as_list()
    outDims = networkOutDiffuse.get_shape().as_list()
    if isTraining:
      diffIn =  data['diffInput']
      specIn = data['specInput']
    else:
      kernelRadius = int(math.floor(FLAGS.reconPatchSize / 2.0))
      diffIn = tf.pad(data['diffInput'], [[0,0], [kernelRadius, kernelRadius], [kernelRadius,kernelRadius], [0,0]], mode='SYMMETRIC')
      specIn = tf.pad(data['specInput'], [[0,0], [kernelRadius, kernelRadius], [kernelRadius,kernelRadius], [0,0]], mode='SYMMETRIC')
    inputSizeY = (FLAGS.reconPatchSize - 1) + outDims[1]
    inputSizeX = (FLAGS.reconPatchSize - 1) + outDims[2]
    croppedDataInDiffuse = utilities.ResizePatch(tf.ones([batchSize, inputSizeY,  inputSizeX, inputDims[3]]), diffIn)
    origInputColorDiffuse = tf.slice(croppedDataInDiffuse, [0,0,0,0], [-1,-1,-1,3])
    croppedDataInSpecular = utilities.ResizePatch(tf.ones([batchSize, inputSizeY,  inputSizeX, inputDims[3]]), specIn)
    origInputColorSpecular = tf.slice(croppedDataInSpecular, [0,0,0,0], [-1,-1,-1,3])
    
    # Apply reconstruction kernel (KPCN)
    networkOutDiffuse = ApplyKernel(networkOutDiffuse, origInputColorDiffuse, batchSize, isTraining, FLAGS)
    networkOutSpecular = ApplyKernel(networkOutSpecular, origInputColorSpecular, batchSize, isTraining, FLAGS)

  # Crop input/gt/albedo patches to match network output
  data = utilities.ResizeAll(data, networkOutDiffuse)

  # Map network outputs to final image
  specTerm = tf.subtract(tf.exp(networkOutSpecular), tf.constant(1.0))
  diffTerm = tf.multiply(networkOutDiffuse, tf.add(data['diffMap'], tf.constant(0.00316)))
  networkOutFinal = tf.add(diffTerm, specTerm)

  return networkOutDiffuse, networkOutSpecular, networkOutFinal


# Evaluate all layers of the network
def FeedForward(data, weights, biases, isTraining):

    # Evaluate input layer. Output of input layer is itself
    prevOut = data

    # Don't consider boundaries when training
    paddingType = 'SAME'
    if isTraining:
        paddingType = 'VALID'
    
    # Evaluate each hidden layer (conv + relu)
    n = len(weights)
    for i in xrange(0, n-1):
        conv = tf.nn.conv2d(prevOut, weights[i], strides=[1, 1, 1, 1], padding=paddingType)
        prevOut = tf.nn.relu(tf.nn.bias_add(conv, biases[i]))

    # Evaluate output layer. Output layer doesn't have activation function (conv only)
    conv = tf.nn.conv2d(prevOut, weights[n-1], strides=[1, 1, 1, 1], padding=paddingType)
    out = tf.nn.bias_add(conv, biases[n-1])

    return out


# Implements softmax activation function (used for kernel prediction)
def Softmax(net):
  
  with tf.name_scope("PerPixelSoftmax", "PerPixelSoftmax", [net]) as scope:
    xmax = tf.reduce_max(net, reduction_indices=1, keep_dims=True)
    net = tf.subtract(net,xmax)
    net = tf.exp(net)
    sum = tf.reduce_sum(net, reduction_indices=1, keep_dims=True)
    return tf.div(net, sum + 1e-4)


# Take the network output, apply the softmax activation (to get weights in range [0,1] and sum = 1), 
# and call the weighted average library to efficiently apply the kernel
def ApplyKernel(netOut, inputColors, batchSize, isTraining, FLAGS):
  
  curShape = netOut.get_shape().as_list()
  assert(len(curShape) == 4)
  
  netOut = tf.reshape(netOut, [batchSize* curShape[1] * curShape[2], curShape[3]])
  weights = Softmax(netOut)
  weights = tf.reshape(weights,[batchSize, curShape[1], curShape[2], curShape[3]])
  out = weighted_average(inputColors, weights)
  
  return out


# Calculates error
# gt是ground truth
def Loss(logits, gt, errorFunc, FLAGS):

    # L2 loss
    if errorFunc == "L2":
        l2Err = tf.nn.l2_loss(tf.subtract(logits, gt))
        l2ErrMean = tf.reduce_mean(l2Err)
        return l2ErrMean

    # LMLS loss
    elif errorFunc == "LMLS":
        r = tf.subtract(logits, gt)
        lmls = tf.reduce_mean(tf.log(1 + (0.5 * tf.reduce_mean(tf.square(r), reduction_indices=3))))
        return lmls

    # RelMse loss
    elif errorFunc == "RELMSE":
        num = tf.square(tf.subtract(logits, gt))
        denom = tf.square(gt) + 1.0e-2
        relMse = num / denom
        relMseMean = 0.5 * tf.reduce_mean(relMse)
        return relMseMean

    # L1 loss
    elif errorFunc == "L1":
        l1Err = tf.abs(tf.subtract(logits, gt))
        l1ErrMean = tf.reduce_mean(l1Err)
        return l1ErrMean

    # MAPE loss (relative L1)
    elif errorFunc == "MAPE":
        l1Err = tf.abs(tf.subtract(logits, gt))
        l1Err = tf.div(l1Err, gt + 1.0e-2)
        l1ErrMean = tf.reduce_mean(l1Err)
        return l1ErrMean

    # SSIM loss
    elif errorFunc == "SSIM":
        return utilities.SSIM(logits, gt, FLAGS)

    else:
        print('Error: Unrecognized error function')


# Calculates the gradients and performs backpropagation
def Train(totalLoss, globalStep, FLAGS):

    # Use ADAM for optimization
    opt = tf.train.AdamOptimizer(learning_rate=FLAGS.learningRate)
    grads = opt.compute_gradients(totalLoss)

    # Clip gradients to avoid exploding weights
    grads = [(None, var) if grad is None else (tf.clip_by_value(grad, -1.0, 1.0), var) for grad, var in grads]

    # Apply gradients
    applyGradientOp = opt.apply_gradients(grads, global_step=globalStep)
    with tf.control_dependencies([applyGradientOp]):
        trainOp = tf.no_op(name='Train')

    return trainOp
