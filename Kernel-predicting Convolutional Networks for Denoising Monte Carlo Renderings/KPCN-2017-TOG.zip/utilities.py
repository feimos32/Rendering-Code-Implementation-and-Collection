import tensorflow as tf
import numpy as np
import exr 
import math
import scipy, scipy.fftpack
import os
import sys
import time
from os.path import isfile, join
from os import listdir
from shutil import copyfile
from skimage import feature
from scipy import ndimage
from scipy.special import expit
from glob import glob
from random import random, randint
from numpy.random import random, randint
from bisect import bisect_left
sys.path.insert(0, 'lib')


# utilities.py: Contains various functions organized in the following sections: "DATA PRE-PROCESSING", "I/O", "SAMPLING", "MISC"


#### DATA PRE-PROCESSING ####


# Convert tungsten data into expected format (data + var in each exr channel)
def ConvertTungstenData(data, appendVariances=True):

    if appendVariances:
        data['albedo'] = np.concatenate((data['albedo'], data['albedoVariance']), axis=2)
        data['diffuse'] = np.concatenate((data['diffuse'], data['diffuseVariance']), axis=2)
        data['specular'] = np.concatenate((data['specular'], data['specularVariance']), axis=2)
        data['normal'] = np.concatenate((data['normal'], data['normalVariance']), axis=2)
    data['camDepth'] = data['depthVariance'].copy()
    return data


# Preprocess data
def ConvertExrToTensor(inputfile, gtfile, batchSize, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
                        featureListSpec, featureLengthsSpec, FLAGS):

  # Read in noisy data
  data = exr.read_all(inputfile)
  data = ConvertTungstenData(data)
  for key, val in data.viewitems():
    data[key] = np.nan_to_num(val)

  # Read in reference (gt) data
  gtData = exr.read_all(gtfile)
  gtData = ConvertTungstenData(gtData)
  for key, val in gtData.viewitems():
    gtData[key] = np.nan_to_num(val)

  # Divide out albedo to get diffuse illumination
  dataDiff = DivideAlbedo(data['diffuse'], data['albedo'])
  diffReference = DivideAlbedo(gtData['diffuse'], gtData['albedo'])

  # Concatenate specular data to channels
  data['Reference'] = np.concatenate((diffReference[:,:,:3].copy(), gtData['specular'][:,:,:3].copy()), axis=-1)
  data['default'] = np.concatenate((dataDiff[:,:,:3].copy(), data['specular'][:,:,:3].copy()), axis=-1)

  # Save albedo for computing the final image
  data['diffMap'] = data['albedo'][:,:,:3].copy()

  # Save diffuse and specular variance 
  albedoSquared = np.expand_dims(CalcMean(data['albedo']),axis=2)
  albedoSquared *= albedoSquared
  data['difflum'] = DivideAlbedo(data['diffuse'][:,:,-1:],  albedoSquared)
  data['speclum'] = data['specular'][:,:,-1:].copy()

  # Save out final input and reference to calculate errors, etc.
  data['finalGt'] = ApplyAlbedo(data['Reference'][:,:,:3], data['diffMap']) + data['Reference'][:,:,3:]
  data['finalInput'] = ApplyAlbedo(data['default'][:,:,:3], data['diffMap']) + data['default'][:,:,3:]

  # Clip the depths to zero just in case
  data['depth'] = np.clip(data['depth'], 0, np.max(data['depth']))

  # Normalize current frame depth to [0,1]
  maxDepth = np.max(data['depth'])
  if maxDepth != 0:
      data['depth'] /= maxDepth
      data['camDepth'] /= (maxDepth * maxDepth)
  data['depth'] = np.concatenate((data['depth'], data['camDepth']), axis=2)

  # Clip specular data to avoid negative values for log transform
  data['specular'][:,:,:3] = np.clip(data['specular'][:,:,:3], 0, np.max(data['specular'][:,:,:3])) 
  data['default'][:,:,3:6] = np.clip(data['default'][:,:,3:6], 0, np.max(data['default'][:,:,3:6]))
  data['Reference'][:,:,3:6] = np.clip(data['Reference'][:,:,3:6], 0, np.max(data['Reference'][:,:,3:6])) 
  
  # Correct specular variance based on log transform
  data['speclum'] = CalcRelVar((1 + data['default'][:,:,3:].copy()), data['speclum'], False, False, True) 
  
  # Take log transform of specular data
  data['specular'][:,:,:3] = LogTransform(data['specular'][:,:,:3])
  data['default'][:,:,3:6] = LogTransform(data['default'][:,:,3:6])
  data['Reference'][:,:,3:6] = LogTransform(data['Reference'][:,:,3:6])

  # Calculate gradients of features
  data['gradNormal'] = CalcGrad(data['normal'][:, :, :3].copy())
  data['gradDepth'] = CalcGrad(data['depth'][:, :, :1].copy())
  data['gradAlbedo'] = CalcGrad(data['albedo'][:, :, :3].copy())
  data['gradSpecular'] = CalcGrad(data['specular'][:, :, :3].copy())
  data['gradDiffuse'] = CalcGrad(data['diffuse'][:, :, :3].copy())
  data['gradIrrad'] = CalcGrad(data['default'][:, :, :3].copy())
      
  # Concatenate variances to the end of the gradients
  data['gradNormal'] = np.concatenate((data['gradNormal'], data['normal'][:,:,-1:].copy()), axis=2)
  data['gradDepth'] = np.concatenate((data['gradDepth'], data['depth'][:,:,-1:].copy()), axis=2)
  data['gradAlbedo'] = np.concatenate((data['gradAlbedo'], data['albedo'][:,:,-1:].copy()), axis=2)
  data['gradSpecular'] = np.concatenate((data['gradSpecular'], data['speclum'].copy()), axis=2)
  data['gradDiffuse'] = np.concatenate((data['gradDiffuse'], data['diffuse'][:,:,-1:].copy()), axis=2)
  data['gradIrrad'] = np.concatenate((data['gradIrrad'], data['difflum'].copy()), axis=2)

  # Remove superfluous info (but keep normals for importance sampling)
  featureListFull += ['normal'] 
  featureLengthsFull += [4]
  RemoveData(data, featureListFull)
  
  # Loop through all data and keep only desired lengths in each channel
  index = 0
  dataLengths = {}
  for key in featureListFull: 
      data[key] = data[key][:, :, 0:featureLengthsFull[index]]
      dataLengths[key] = featureLengthsFull[index]
      index += 1

  # Generate tfrecords for training
  if FLAGS.generateTrainingData:

    return data, dataLengths

  # Otherwise we are testing and we need to save the exr in tf format
  else:

    [imgHeight, imgWidth] = data['default'].shape[:-1]
    data = InputExr(data, batchSize, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
                    featureListSpec, featureLengthsSpec, imgHeight, imgWidth, FLAGS)
    return data, tf.constant(imgWidth), tf.constant(imgHeight)


# Remove channels from data that are not in labelsToKeep
def RemoveData(data, labelsToKeep):

  keysToDelete = []
  for key, val in data.viewitems():
    if not key in labelsToKeep:
      keysToDelete.append(key)
  for key in keysToDelete:
    del data[key]


# Calculate gradients with finite differencing
def CalcGrad(data):

    h, w, c = data.shape
    dX = data[:, 1:, :] - data[:, :w - 1, :]
    dY = data[1:, :, :] - data[:h - 1, :, :]
    dX = np.concatenate((np.zeros([h,1,c]),dX), axis=1)
    dY = np.concatenate((np.zeros([1,w,c]),dY), axis=0)
    return np.concatenate((dX, dY), axis=2)


# Multiply illumination by albedo to get final image
def ApplyAlbedo(val, albedo):

    return (val * (albedo + 0.00316))


# Divide albedo to get illumination (regularization term to avoid div by zero)
def DivideAlbedo(val, albedo):

    return (val / (albedo + 0.00316))


# Calculate log transform (with an offset to map zero to zero)
def LogTransform(data):

    assert(np.sum(data < 0) == 0)
    return np.log(data + 1.0)


# Calculate luminance (3 channels in and 1 channel out)
def CalcLuminance(data):

    return (0.2126*data[:,:,0] + 0.7152*data[:,:,1] + 0.0722*data[:,:,2])


# Calculate mean (3 channels in and 1 channel out)
def CalcMean(data):

    return (0.3333*data[:,:,0] + 0.3333*data[:,:,1] + 0.3333*data[:,:,2])


# Divide variance by mean^2 to get relative variance
def CalcRelVar(data, var, calcLog, calcLum=True, calcMean=False):

    if calcLum:
      denom = np.expand_dims(CalcLuminance(data), axis=2)
    elif calcMean:
      denom = np.expand_dims(CalcMean(data), axis=2)
    else:
        denom = data
    var = var / ((denom * denom) + 1.0e-5)
    if calcLog:
        var = LogTransform(var)
    return var


#### I/O ####


# Read input data from tfrecord and return a batch of patches
def Inputs(filename, shuffle, batchSize, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
            featureListSpec, featureLengthsSpec, FLAGS):

  if not tf.gfile.Exists(filename):
    raise ValueError('Failed to find file: ' + filename)

  # Create a queue that produces the filenames to read.
  filenameQueue = tf.train.string_input_producer([filename])

  # Read examples from files in the filename queue.
  reader = tf.TFRecordReader()
  _, exampleSerialized = reader.read(filenameQueue)
  dataList, dataLengths = ParseExample(exampleSerialized, featureListFull, featureLengthsFull, featureListDiff, 
                                        featureLengthsDiff, featureListSpec, featureLengthsSpec, FLAGS)

  # Generate a batch of images and labels by building up a queue of examples.
  return GenerateBatch(dataList, batchSize, shuffle, dataLengths, FLAGS)


# Read in the tfrecord and convert it to a tf tensor
def ParseExample(exampleSerialized, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
                  featureListSpec, featureLengthsSpec, FLAGS):

  # Get all of the features in the data
  featureMap = {key: tf.FixedLenFeature([], dtype=tf.string, default_value='') for key in featureListFull}
  features = tf.parse_single_example(exampleSerialized, featureMap)

  dataList, dataLengths = AddData(features, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
                                    featureListSpec, featureLengthsSpec, FLAGS)

  return dataList, dataLengths


# Create a batch of patches
def GenerateBatch(dataList, batchSize, shuffle, dataLengths, FLAGS):

  # Shuffle patches rather than read them consecutively. Useful for training
  if shuffle:
    minAfterDequeue = 10000
    capacity = minAfterDequeue + 3 * batchSize
    dataList = tf.train.shuffle_batch(dataList, batch_size=batchSize, num_threads=1, capacity=capacity,
                                      min_after_dequeue=minAfterDequeue)
  else:
    dataList = tf.train.batch(dataList, batch_size=batchSize, num_threads=1)

  # Reshape patches to be [batchSize, patchSize, patchSize, numChannels]
  for key, val in dataList.viewitems():
    dataList[key] = tf.reshape(val, shape=[batchSize, FLAGS.patchSize, FLAGS.patchSize, dataLengths[key]])

  return dataList


# Parse all the data and send them to the right location (e.g., data for diffuse network, data for spec network, etc.)
def AddData(features, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, featureListSpec, 
            featureLengthsSpec, FLAGS):

  dataList = {}
  dataLengths = {}
  inputListDiff = []
  inputListSpec = []
  inputLengthDiff = 0
  inputLengthSpec = 0
  index = 0
  indexDiff = 0
  indexSpec = 0
  
  for key in featureListFull:
    
    curData = tf.decode_raw(features[key], tf.float32)
    curData.set_shape([FLAGS.patchSize * FLAGS.patchSize * featureLengthsFull[index]])
    curData = tf.reshape(curData, shape=[FLAGS.patchSize * FLAGS.patchSize, featureLengthsFull[index]])
    
    if key == 'finalGt' or key == 'finalInput' or key == 'diffMap' or key == 'specMap':
      
      dataList[key] = curData
      dataLengths[key] = featureLengthsFull[index]
    
    elif key == 'Reference':
      
      dataList['diffGt'] = tf.slice(curData, [0,0], [-1,FLAGS.outputChannels])
      dataList['specGt'] = tf.slice(curData, [0,FLAGS.outputChannels], [-1,FLAGS.outputChannels])
      dataLengths['diffGt'] = FLAGS.outputChannels
      dataLengths['specGt'] = FLAGS.outputChannels
      assert(2*FLAGS.outputChannels == featureLengthsFull[index])
      indexDiff += 1
      indexSpec += 1
    
    else:
      
      curFeatLength = featureLengthsFull[index]
      curDataDiff = curData
      curDataSpec = curData
      
      if key == 'default':
        
        curDataDiff = tf.slice(curData, [0,0], [-1,FLAGS.outputChannels]) 
        curDataSpec = tf.slice(curData, [0,FLAGS.outputChannels], [-1,FLAGS.outputChannels]) 
        assert(curFeatLength == 2*FLAGS.outputChannels)
        curFeatLength = FLAGS.outputChannels

      curDataDiff = tf.reshape(curDataDiff, shape=[FLAGS.patchSize, FLAGS.patchSize, curFeatLength])
      curDataSpec = tf.reshape(curDataSpec, shape=[FLAGS.patchSize, FLAGS.patchSize, curFeatLength])
      
      if key in featureListDiff:
        
        inputListDiff.append(curDataDiff)
        inputLengthDiff += curFeatLength
        assert(curFeatLength == featureLengthsDiff[indexDiff])
        indexDiff += 1
      
      if key in featureListSpec:
        
        inputListSpec.append(curDataSpec)
        inputLengthSpec += curFeatLength
        assert(curFeatLength == featureLengthsSpec[indexSpec])
        indexSpec += 1

    index += 1

  assert(index == len(featureListFull) and indexDiff == len(featureListDiff) and indexSpec == len(featureListSpec))
  
  dataList['diffInput'] = tf.reshape(tf.concat(inputListDiff, 2), shape=[FLAGS.patchSize * FLAGS.patchSize * inputLengthDiff])
  dataLengths['diffInput'] = inputLengthDiff
  dataList['specInput'] = tf.reshape(tf.concat(inputListSpec, 2), shape=[FLAGS.patchSize * FLAGS.patchSize * inputLengthSpec])
  dataLengths['specInput'] = inputLengthSpec
  
  return dataList, dataLengths


# Construct img of zeros of size imgDim for each feature in list of size lengths.
# Reference channel can be skipped
def InitializeImg(imgDim, list, lengths, skipReference, FLAGS):
  
  img = {}
  index = 0
  for key in list:
    if key == 'Reference' and skipReference:
      index += 1
      continue
    img[key] = np.zeros((imgDim[0], imgDim[1], lengths[index]), dtype=float)
    index += 1
  return img


# Write array to image
def WriteImage(filename, data):

  # Add extension
  filename += '.exr'

  # Look at each channel and find the ones that are too big (>4)
  splitData = []
  splitKeys = []
  for key, val in data.viewitems():
    numDims = data[key].shape[2]
    splitSize = 4
    if(numDims > splitSize):
      numOfSplits = numDims / splitSize
      if(splitSize % numDims != 0):
        numOfSplits += 1
      startInd = 0
      endInd = splitSize
      tmp = []
      for i in xrange(0, numOfSplits):
        endInd = min(endInd, numDims)
        assert(startInd <= endInd)
        tmp.append(data[key][:,:,startInd:endInd])
        startInd += splitSize
        endInd += splitSize
      splitData.append(tmp)
      splitKeys.append(key)

  # Actually do the splitting if necessary
  for i in xrange(0, len(splitData)):
    del data[splitKeys[i]]
    for j in xrange(0, len(splitData[i])):
      if j == 0:
        curKey = key
      else:
        curKey = splitKeys[i] + str(j)
      data[curKey] = splitData[i][j]

  # Write exr
  exr.write(filename, data)


# Loop through the imgList and write image to dirList. Both dirList and imgList are dictionaries
# of the same size and same keys
def WriteAllImages(dirList, imgList):

  for key, _ in dirList.viewitems():
    WriteImage(dirList[key], imgList[key])
  return


# Crop patch from all channels of data. The center of patch is specified by index in "ind".
# The size of the patch is (2*halfPatch + 1) x (2*halfPatch + 1)
def Crop(data, ind, halfPatch):

  sx = halfPatch
  sy = halfPatch
  px, py = ind
  return {key: val[(py-sy):(py+sy+1),(px-sx):(px+sx+1),:] 
          for key, val in data.viewitems()}


# Read input data from exr and return a tensor
def InputExr(data, batchSize, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
            featureListSpec, featureLengthsSpec, imgHeight, imgWidth, FLAGS):

  # We process the whole image at once
  assert(batchSize == 1) 

  dataList, dataLengths = AddDataExr(data, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, 
                                    featureListSpec, featureLengthsSpec, imgHeight, imgWidth, FLAGS)

  # Generate a single batch
  dataList = tf.train.batch(dataList, batch_size=batchSize, num_threads=1)

  # Reshape patches to be [1, imgHeight, imgWidth, numChannels]
  for key, val in dataList.viewitems():
    dataList[key] = tf.reshape(val, shape=[batchSize, imgHeight, imgWidth, dataLengths[key]])
 
  return dataList


# Convert exr to tensorflow format
def AddDataExr(data, featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, featureListSpec, 
                featureLengthsSpec, imgHeight, imgWidth, FLAGS):
  
  dataList = {}
  dataLengths = {}
  inputListDiff = []
  inputListSpec = []
  inputLengthDiff = 0
  inputLengthSpec = 0
  index = 0
  indexDiff = 0
  indexSpec = 0
  
  for key in featureListFull:
    
    curData = tf.constant(data[key], dtype=tf.float32)
    curData = tf.reshape(curData, shape=[imgHeight * imgWidth, featureLengthsFull[index]])
    
    if key == 'finalGt' or key == 'finalInput' or key == 'diffMap' or key == 'specMap':
      
      dataList[key] = curData
      dataLengths[key] = featureLengthsFull[index]
    
    elif key == 'Reference':
      
      dataList['diffGt'] = tf.slice(curData, [0,0], [-1,FLAGS.outputChannels])
      dataList['specGt'] = tf.slice(curData, [0,FLAGS.outputChannels], [-1,FLAGS.outputChannels])
      dataLengths['diffGt'] = FLAGS.outputChannels
      dataLengths['specGt'] = FLAGS.outputChannels
      assert(2*FLAGS.outputChannels == featureLengthsFull[index])
      indexDiff += 1
      indexSpec += 1
    
    else:
      
      curFeatLength = featureLengthsFull[index]
      curDataDiff = curData
      curDataSpec = curData
      
      if key == 'default':
        curDataDiff = tf.slice(curData, [0,0], [-1,FLAGS.outputChannels]) 
        curDataSpec = tf.slice(curData, [0,FLAGS.outputChannels], [-1,FLAGS.outputChannels]) 
        assert(curFeatLength == 2*FLAGS.outputChannels)
        curFeatLength = FLAGS.outputChannels

      curDataDiff = tf.reshape(curDataDiff, shape=[imgHeight, imgWidth, curFeatLength])
      curDataSpec = tf.reshape(curDataSpec, shape=[imgHeight, imgWidth, curFeatLength])
      
      if key in featureListDiff:
        
        inputListDiff.append(curDataDiff)
        inputLengthDiff += curFeatLength
        assert(curFeatLength == featureLengthsDiff[indexDiff])
        indexDiff += 1
      
      if key in featureListSpec:
        
        inputListSpec.append(curDataSpec)
        inputLengthSpec += curFeatLength
        assert(curFeatLength == featureLengthsSpec[indexSpec])
        indexSpec += 1

    index += 1

  assert(index == len(featureListFull) and indexDiff == len(featureListDiff) and indexSpec == len(featureListSpec))
  
  dataList['diffInput'] = tf.reshape(tf.concat(inputListDiff, 2), shape=[imgHeight * imgWidth * inputLengthDiff])
  dataLengths['diffInput'] = inputLengthDiff
  dataList['specInput'] = tf.reshape(tf.concat(inputListSpec, 2), shape=[imgHeight * imgWidth * inputLengthSpec])
  dataLengths['specInput'] = inputLengthSpec
  
  return dataList, dataLengths


# Evaluate the error on the full image and save out the result
def EvaluateAndWriteFullExr(sess, imgDir, step, featureListFull, featureListDiff, featureLengthsDiff, 
                              featureListSpec, featureLengthsSpec, evalArgs, filename, FLAGS, writeImages=True):

  startTime = time.time()
  # Evaluate the graph
  outData = sess.run(evalArgs)
  netTime = time.time() - startTime
  print("Network evaluation: %f seconds" % (netTime))

  # Save error
  loss = {}
  loss['diff'] = outData[0]
  loss['spec'] = outData[1]
  loss['final'] = outData[2]
  loss['ssim'] = outData[12]
  loss['l1'] = outData[13]
  loss['relmse'] = outData[14]
  loss['mape'] = outData[15]

  if writeImages: 

    # Current image height and width
    imgDim = [outData[17], outData[16]]

    # Diffuse images
    noisyDiff = InitializeImg(imgDim, featureListDiff, featureLengthsDiff, True, FLAGS)
    outDiff = InitializeImg(imgDim, ['default'], [FLAGS.outputChannels], True, FLAGS)
    gtDiff = InitializeImg(imgDim, ['Reference'], [FLAGS.outputChannels], False, FLAGS)

    # Specular images
    noisySpec = InitializeImg(imgDim, featureListSpec, featureLengthsSpec, True, FLAGS)
    outSpec = InitializeImg(imgDim, ['default'], [FLAGS.outputChannels], True, FLAGS)
    gtSpec = InitializeImg(imgDim, ['Reference'], [FLAGS.outputChannels], False, FLAGS)

    # Final images
    noisyFinal = InitializeImg(imgDim, ['default'], [FLAGS.outputChannels], True, FLAGS)
    outFinal = InitializeImg(imgDim, ['default'], [FLAGS.outputChannels], True, FLAGS)
    gtFinal = InitializeImg(imgDim, ['Reference'], [FLAGS.outputChannels], False, FLAGS)

    # Construct a dictionary of the images to save
    imgList = {}
    dataList = {}

    # Save data
    imgList['outDiff'] = {}
    imgList['outDiff']['default'] = outData[4][0,:,:,:]
    imgList['outSpec'] = {}
    imgList['outSpec']['default'] = outData[7][0,:,:,:]
    imgList['outFinal'] = {}
    imgList['outFinal']['default'] = outData[10][0,:,:,:]
    
    # Save out input and gt on first iteration
    if step == 0 or not FLAGS.isTraining:
      
      imgList['noisyDiff'] = {}
      imgList['noisyDiff']['default'] = outData[3][0,:,:,:3]
      imgList['gtDiff'] = {}
      imgList['gtDiff']['Reference'] = outData[5][0,:,:,:]
      imgList['noisySpec'] = {}
      imgList['noisySpec']['default'] = outData[6][0,:,:,:3]
      imgList['gtSpec'] = {}
      imgList['gtSpec']['Reference'] = outData[8][0,:,:,:]
      imgList['noisyFinal'] = {}
      imgList['noisyFinal']['default'] = outData[9][0,:,:,:3]        
      imgList['gtFinal'] = {}
      imgList['gtFinal']['Reference'] = outData[11][0,:,:,:]

    # Actually write the image
    print("Saving data for %s" % (filename))
    dirList = {}
    basefilename = os.path.splitext(filename)[0]
    if step == 0 or not FLAGS.isTraining:
      dirList['noisyDiff'] = imgDir + "/" + basefilename + "_InDiff"
      dirList['gtDiff'] = imgDir + "/" + basefilename + "_GtDiff"
      dirList['noisySpec'] = imgDir + "/" + basefilename + "_InSpec"
      dirList['gtSpec'] = imgDir + "/" + basefilename + "_GtSpec"
      dirList['noisyFinal'] = imgDir + "/" + basefilename + "_InFinal"
      dirList['gtFinal'] = imgDir + "/" + basefilename + "_GtFinal"
    dirList['outDiff'] = imgDir + "/" + basefilename + "_OutDiff_" + str(step)
    dirList['outSpec'] = imgDir + "/" + basefilename + "_OutSpec_" + str(step)
    dirList['outFinal'] = imgDir + "/" + basefilename + "_OutFinal_" + str(step)
    WriteAllImages(dirList, imgList)

  return loss


# Write the data array data at each key to the tfrecord which is read in by tensorflow
def WriteTfRecord(data, writer):

    def bytes(value):
        return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

    features = {key: bytes(val.astype(np.float32).tobytes())
                for key, val in data.viewitems()}
    ex = tf.train.Example(features=tf.train.Features(feature=features))
    writer.write(ex.SerializeToString())


# Find the scene's corresponding reference (gt)
def FindGt(scenename, gtDir, FLAGS):
  
  frameNum = scenename.split("-")[0]
  gtPattern = '%s*.exr' % (frameNum)

  gtfiles = glob(os.path.join(gtDir, gtPattern))
  assert(len(gtfiles) == 1)
  return gtfiles[0]


# Check if patch is all black
def IsAllBlack(patch):

    return not np.any(patch['default'])


# Split channels if saving more than 4 channels out
def SplitChannels(data):

    for key, val in sorted(data.viewitems()):
        if val.shape[-1] >= 6:
            data[key + "0"] = data[key][:,:,:3]
            data[key + "1"] = data[key][:,:,3:6]
            
            if val.shape[-1] == 7:
                data[key + "var"] = data[key][:,:,-1]

            del data[key]
    return data


# Loop through all the scenes in the input directory, read in each frame, importance sample, and save to the tfrecord
def GenerateTrainingData(featureListFull, featureLengthsFull, featureListDiff, featureLengthsDiff, featureListSpec, 
                          featureLengthsSpec, FLAGS):

    # Make output folder
    if not os.path.exists(FLAGS.outputDir):
        os.makedirs(FLAGS.outputDir)

    # Make directories for saving debug images
    if FLAGS.saveImages:
        if not os.path.exists(FLAGS.debugDir):
            os.makedirs(FLAGS.debugDir)
        if not os.path.exists(FLAGS.debugDir + 'Sampling/'):
            os.makedirs(FLAGS.debugDir + 'Sampling/')

    # Open the tfrecord for writing
    outputFile = "%s%s.tfrecord" % (FLAGS.outputDir, FLAGS.dataName)
    if os.path.isfile(outputFile):
      print("Error: Output file exists!")
      return
    writer = tf.python_io.TFRecordWriter(outputFile)

    # Find all scenes in the input directory and shuffle if desired
    onlyfiles = glob(os.path.join(FLAGS.inputDir, '*.exr'))
    if FLAGS.shuffleFiles:
        np.random.shuffle(onlyfiles)
    else:
        onlyfiles.sort()

    # For each scene write out the data
    index = 1
    for f in onlyfiles:

      print("Working on file %d of %d..." % (index, len(onlyfiles)))
      index += 1
      startTime = time.time()

      # Read in data of current frame
      scene = f.split("/")[-1]
      gtscene = FindGt(scene, FLAGS.gtDir, FLAGS)
      data, dataLengths = ConvertExrToTensor(f, gtscene, None, featureListFull, 
                                                          featureLengthsFull, featureListDiff, featureLengthsDiff, 
                                                          featureListSpec, featureLengthsSpec, FLAGS)

      # Importance sample the image
      halfPatch = int(math.floor(float(FLAGS.patchSize) / 2.0))
      patches = ImportanceSampling(data, scene, FLAGS)

      # Save out debug images 
      if FLAGS.saveImages:
        dataCopy = data.copy()
        dataCopy = SplitChannels(dataCopy)
        exr.write("%s/%s" % (FLAGS.debugDir, scene), dataCopy)

      # Write sampled patches
      for pi, patch in enumerate(patches):
        curPatch = Crop(data, patch, halfPatch)

        # Typically for non-evaluation sets we want to throw away all black patches
        if FLAGS.discardBlackPatches:
            if IsAllBlack(curPatch):
                continue

        WriteTfRecord(curPatch, writer)

      # Report time per frame
      duration = time.time() - startTime
      print("Done in %d sec" % duration)

    # Close writers
    writer.close


#### SAMPLING ####


def SamplePatchesProg(img_dim, patch_size, n_samples, maxiter=5000):
    
    # Sample patches using dart throwing (works well for sparse/non-overlapping patches)
    
    # estimate each sample patch area
    full_area = float(img_dim[0]*img_dim[1])
    sample_area = full_area/n_samples
    
    # get corresponding dart throwing radius
    radius = np.sqrt(sample_area/np.pi)
    minsqrdist = (2*radius)**2

    # compute the distance to the closest patch
    def get_sqrdist(x, y, patches):
        if len(patches) == 0:
            return np.infty
        dist = patches - [x, y]
        return np.sum(dist**2, axis=1).min()
    
    # perform dart throwing, progressively reducing the radius
    rate = 0.96
    patches = np.zeros((n_samples,2), dtype=int)
    xmin, xmax = 0, img_dim[1] - patch_size[1] - 1
    ymin, ymax = 0, img_dim[0] - patch_size[0] - 1
    for patch in range(n_samples):
        done = False
        while not done:
            for i in range(maxiter):
                x = randint(xmin, xmax)
                y = randint(ymin, ymax)
                sqrdist = get_sqrdist(x, y, patches[:patch,:])
                if sqrdist > minsqrdist:
                    patches[patch,:] = [x, y]
                    done = True
                    break
            if not done:
                radius *= rate
                minsqrdist = (2*radius)**2
    
    return patches


def GetVarianceMap(data, patchsize, relative=False):

    # introduce a dummy third dimension if needed
    if data.ndim < 3:
        data = data[:,:,np.newaxis]

    # compute variance
    mean = ndimage.uniform_filter(data, size=(patchsize, patchsize, 1))
    sqrmean = ndimage.uniform_filter(data**2, size=(patchsize, patchsize, 1))
    variance = np.maximum(sqrmean - mean**2, 0)

    # convert to relative variance if requested
    if relative:
        variance = variance/np.maximum(mean**2, 1e-2)

    # take the max variance along the three channels, gamma correct it to get a
    # less peaky map, and normalize it to the range [0,1]
    variance = variance.max(axis=2)
    variance = np.minimum(variance**(1.0/2.2), 1.0)

    return variance/variance.max()


# Generate importance sampling map based on buffer and desired metric
def GetImportanceMap(buffers, metrics, weights, patchsize):

    if len(metrics) != len(buffers):
        metrics = [metrics[0]]*len(buffers)
    if len(weights) != len(buffers):
        weights = [weights[0]]*len(buffers)
    imp = None
    for buf, metric, weight in zip(buffers, metrics, weights):
        if metric == 'uniform':
            cur = np.ones(buf.shape[:2], dtype=np.float)
        elif metric == 'variance':
            cur = GetVarianceMap(buf, patchsize, relative=False)
        elif metric == 'relvar':
            cur = GetVarianceMap(buf, patchsize, relative=True)
        else:
            print('Unexpected metric:', args.metric)
        if imp is None:
            imp = cur*weight
        else:
            imp += cur*weight
    return imp/imp.max()


def PrunePatches(shape, patches, patchsize, imp):

    pruned = np.empty_like(patches)

    # Generate a set of regions tiling the image using snake ordering.
    def get_regions_list(shape, step):
        regions = []
        for y in range(0, shape[0], step):
            if y//step % 2 == 0:
                xrange = range(0, shape[1], step)
            else:
                xrange = reversed(range(0, shape[1], step))
            for x in xrange:
                regions.append((x, x + step, y, y + step))
        return regions

    # Split 'patches' in current and remaining sets, where 'cur' holds the
    # patches in the requested region, and 'rem' holds the remaining patches.
    def split_patches(patches, region):
        cur = np.empty_like(patches)
        rem = np.empty_like(patches)
        ccount, rcount = 0, 0
        for i in range(patches.shape[0]):
            x, y = patches[i,0], patches[i,1]
            if region[0] <= x < region[1] and region[2] <= y < region[3]:
                cur[ccount,:] = [x,y]
                ccount += 1
            else:
                rem[rcount,:] = [x,y]
                rcount += 1
        return cur[:ccount,:], rem[:rcount,:]

    # Process all patches, region by region, pruning them randomly according to
    # their importance value, ie. patches with low importance have a higher
    # chance of getting pruned. To offset the impact of the binary pruning
    # decision, we propagate the discretization error and take it into account
    # when pruning.
    rem = np.copy(patches)
    count, error = 0, 0
    for region in get_regions_list(shape, 4*patchsize):
        cur, rem = split_patches(rem, region)
        for i in range(cur.shape[0]):
            x, y = cur[i,0], cur[i,1]
            if imp[y,x] - error > random():
                pruned[count,:] = [x, y]
                count += 1
                error += 1 - imp[y,x]
            else:
                error += 0 - imp[y,x]

    return pruned[:count,:]


def ImportanceSampling(data, scene, FLAGS):

    # Load the given file and extract buffers
    buffers = []
    for b in ['default', 'normal']:
        if b in ['default', 'albedo', 'normal']:
            buffers.append(data[b][:,:,:3])
        else:
            buffers.append(data[b])

    # build the metric map
    metrics = ['relvar', 'variance']
    weights = [1.0, 1.0]
    imp = GetImportanceMap(buffers, metrics, weights, FLAGS.patchSize)
    if FLAGS.saveImages:
        exr.write("%s/Sampling/%s_Metric.exr" % (FLAGS.debugDir, scene), imp)

    # get uniformly distributed patches
    patches = SamplePatchesProg(buffers[0].shape[:2], (FLAGS.patchSize, FLAGS.patchSize), FLAGS.numPatchSamples)
    selection = buffers[0]*0.1
    for i in range(patches.shape[0]):
        x, y = patches[i,0], patches[i,1]
        selection[y:y+FLAGS.patchSize,x:x+FLAGS.patchSize,:] = buffers[0][y:y+FLAGS.patchSize,x:x+FLAGS.patchSize,:]
    if FLAGS.saveImages:
        exr.write("%s/Sampling/%s_Uniform.exr" % (FLAGS.debugDir, scene), selection)

    # prune patches
    pad = FLAGS.patchSize//2
    pruned = np.maximum(0, PrunePatches(buffers[0].shape[:2], patches + pad, FLAGS.patchSize, imp) - pad)
    selection = buffers[0]*0.1
    for i in range(pruned.shape[0]):
        x, y = pruned[i,0], pruned[i,1]
        selection[y:y+FLAGS.patchSize,x:x+FLAGS.patchSize,:] = buffers[0][y:y+FLAGS.patchSize,x:x+FLAGS.patchSize,:]
    if FLAGS.saveImages:
        exr.write("%s/Sampling/%s_Pruned2.exr" % (FLAGS.debugDir, scene), selection)

    return (pruned + pad)


#### MISC ####


# SSIM error
def SSIM(a, b, FLAGS):

  # Generate filter kernel
  _, _, _, d = a.get_shape().as_list()
  window = GenerateWeights(5, 1.5)
  window = window / np.sum(window)
  window = window.astype(np.float32)
  window = window[:,:,np.newaxis,np.newaxis]
  window = tf.constant(window)
  window = tf.tile(window,[1, 1, d, 1])

  # Find means
  mA = tf.nn.depthwise_conv2d(a, window, strides=[1, 1, 1, 1], padding='VALID')
  mB = tf.nn.depthwise_conv2d(b, window, strides=[1, 1, 1, 1], padding='VALID')

  # Find standard deviations
  sA = tf.nn.depthwise_conv2d(a*a, window, strides=[1, 1, 1, 1], padding='VALID') - mA**2
  sB = tf.nn.depthwise_conv2d(b*b, window, strides=[1, 1, 1, 1], padding='VALID') - mB**2
  sAB = tf.nn.depthwise_conv2d(a*b, window, strides=[1, 1, 1, 1], padding='VALID') - mA*mB

  # Calc SSIM constants 
  L = 1.0
  k1 = 0.01
  k2 = 0.03
  c1 = (k1 * L)**2
  c2 = (k2 * L)**2

  # Plug into SSIM equation
  assert(c1 > 0 and c2 > 0)
  p1 = (2.0*mA*mB + c1)/(mA*mA + mB*mB + c1)
  p2 = (2.0*sAB + c2)/(sA + sB + c2)

  # We want to maximize SSIM or minimize (1-SSIM)
  return 1-tf.reduce_mean(p1*p2)


# Generate normalized gaussian weights in a (2*radius + 1) x (2*radius + 1) window
# with specified sigma (SSIM helper function)
def GenerateWeights(radius, sigma):

  weight = np.zeros([2*radius + 1, 2*radius + 1])
  expFactor = -1.0 / (2 * sigma * sigma)
  for i in xrange(-radius, radius + 1):
    for j in xrange(-radius, radius + 1):
      weight[i+radius,j+radius] = np.exp(expFactor * (i * i + j * j))
  weightSum = np.sum(weight)
  assert(weightSum > 0)
  return weight / weightSum


# Save error in errList[i] in location dirList[folderNames[i]]
def SaveErrorList(dirList, folderNames, errList, name, step):
  
  index = 0
  for folder in folderNames:
    WriteError(dirList[folder], errList[index], name, step)
    index += 1


# Save new error file or append it to the current one
def WriteError(dir, val, name, step):
  
  if step == 0:
    fp = open(dir + name, 'w')
  else:
    fp = open(dir + name, 'a')
  fp.write(str(val))
  fp.write("\n")
  fp.close()


# Update error to start at startIter
def UpdateError(dir, startIter, FLAGS):

  fp = open(dir + "Error.txt", 'r')
  lines = fp.readlines()
  fp.close()
  index = 0
  fp = open(dir + "Error.txt", 'w')
  for l in lines:
    if (index == startIter):
      break
    fp.write(l)
    index += FLAGS.numItersForEval
  fp.close()


# Initialize dictionary of errors to zero
def InitializeErrors():
  
  errors = {}
  errors['final'] = 0
  errors['diff'] = 0
  errors['spec'] = 0
  errors['ssim'] = 0
  errors['l1'] = 0
  errors['relmse'] = 0
  errors['mape'] = 0
  return errors


# Crops the data patch to match the src
def ResizePatch(src, data):

  srcShape = src.get_shape()
  srcDims = srcShape.as_list()
  dataShape = data.get_shape()
  dataDims = dataShape.as_list()
  if (dataDims[1] != srcDims[1]):
    data = tf.image.extract_glimpse(data, tf.constant(srcDims[1:3]), tf.zeros([tf.shape(src)[0],2], dtype=tf.float32))
  return data

# Resize all channels of data
def ResizeAll(data, sizeToMatch):

  for key, val in data.viewitems():
      data[key] = ResizePatch(sizeToMatch, val)
  return data

